/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : 초음파 거리 센서를 사용한 거리 측정 프로그램
  ******************************************************************************
  * @attention
  * - HC-SR04 초음파 센서를 사용하여 물체와의 거리를 측정합니다.
  * - 측정된 거리는 SSD1306 OLED 디스플레이에 출력됩니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // STM32 초기화 관련 헤더
#include "i2c.h"         // I2C 초기화 및 제어 관련 헤더
#include "tim.h"         // 타이머 설정 및 초기화 관련 헤더
#include "gpio.h"        // GPIO 설정 및 제어 관련 헤더

/* USER CODE BEGIN Includes */
#include "fonts.h"       // SSD1306 디스플레이용 글꼴
#include "ssd1306.h"     // SSD1306 디스플레이 제어 라이브러리
#include "stdio.h"       // 문자열 및 데이터 처리 라이브러리
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
#define TRIG_PIN GPIO_PIN_0              // HC-SR04 TRIG 핀
#define TRIG_PORT GPIOB                  // HC-SR04 TRIG 포트
#define ECHO_PIN GPIO_PIN_14             // HC-SR04 ECHO 핀
#define ECHO_PORT GPIOB                  // HC-SR04 ECHO 포트

uint32_t pMillis;                        // ECHO 핀 상승 에지 시간
uint32_t Value1 = 0;                     // 타이머 카운터 값 1
uint32_t Value2 = 0;                     // 타이머 카운터 값 2
uint16_t Distance = 0;                   // 계산된 거리 (cm 단위)
char strCopy[15];                        // 문자열 버퍼
/* USER CODE END PV */

/* Function prototypes -------------------------------------------------------*/
void SystemClock_Config(void);           // 시스템 클럭 설정 함수

/* USER CODE BEGIN 0 */
// 사용자 정의 함수나 변수 선언 가능
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  HAL_Init();                      // HAL 라이브러리 초기화
  SystemClock_Config();            // 시스템 클럭 설정
  MX_GPIO_Init();                  // GPIO 초기화 (HC-SR04 및 OLED 디스플레이 설정)
  MX_I2C3_Init();                  // I2C 초기화 (SSD1306 통신용)
  MX_TIM1_Init();                  // TIM1 초기화 (초음파 신호 시간 측정용)

  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim1);      // TIM1 타이머 시작
  HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);  // TRIG 핀 초기화
  SSD1306_Init();                  // SSD1306 OLED 디스플레이 초기화
  /* USER CODE END 2 */

  while (1)
  {
      /* USER CODE BEGIN WHILE */
      HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_SET);  // TRIG 핀 HIGH
      __HAL_TIM_SET_COUNTER(&htim1, 0);                     // 타이머 초기화
      while (__HAL_TIM_GET_COUNTER(&htim1) < 10);           // 10us 대기
      HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);  // TRIG 핀 LOW

      // ECHO 핀이 HIGH로 상승하는 시간 기록
      pMillis = HAL_GetTick(); // 타임아웃 방지를 위한 시간 저장
      while (!(HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN)) && pMillis + 10 > HAL_GetTick());
      Value1 = __HAL_TIM_GET_COUNTER(&htim1);

      // ECHO 핀이 LOW로 떨어지는 시간 기록
      pMillis = HAL_GetTick();
      while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) && pMillis + 50 > HAL_GetTick());
      Value2 = __HAL_TIM_GET_COUNTER(&htim1);

      // 거리 계산
      Distance = (Value2 - Value1) * 0.034 / 2;

      // OLED 디스플레이에 거리 출력
      SSD1306_GotoXY(0, 0);
      SSD1306_Puts("Distance:", &Font_11x18, 1);
      sprintf(strCopy, "%d cm", Distance);
      SSD1306_GotoXY(0, 30);
      SSD1306_Puts(strCopy, &Font_16x26, 1);
      SSD1306_UpdateScreen();

      HAL_Delay(50); // 50ms 대기
      /* USER CODE END WHILE */
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
